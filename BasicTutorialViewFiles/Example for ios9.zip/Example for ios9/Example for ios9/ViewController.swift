//
//  ViewController.swift
//  Example for ios9
//
//  Created by Alan Roldán Maillo on 14/6/16.
//  Copyright © 2016 Alan Roldán Maillo. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let window1 = windowView()
    let window2 = windowView()

    var titles = [String]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        titles = ["Touch and turn the hexagon","Select the same color as the ball","If the color is different the ball fall","Plays with both hands to spin faster"]
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func pressModelOne(sender: AnyObject) {
        
        let images = ["img1","img2","img3","img4"]
        window1.modelOne(self, arrayImages: images, arrayTitles: titles)
    }
    
    @IBAction func pressModelTwo(sender: AnyObject) {
        
        let images = ["img5","img6","img7","img8"]
        window2.modelTwo(self, arrayImages: images, arrayTitles: titles)
    }
}

